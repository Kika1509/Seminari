package hr.fer.diplproj.ann.nn.train;

import hr.fer.diplproj.ann.nn.structure.Layer;
import hr.fer.diplproj.ann.nn.structure.Network;

/**
 * Class which provides the implementation of a stohastic backpropagation algorithm.
 * It runs only one training epoch.
 * @author Andrea Zlati�
 *
 */

public class StohasticBackpropagation {

	private static double eta = 0.7;
	private static int sampleNum = 100000;

	/**
	 * Setter for training parameters
	 * @param eta learning rate
	 * @param sampleNum number of random generated samples
	 */
	public static void setParams(double eta, int sampleNum) {
		StohasticBackpropagation.eta = eta;
		StohasticBackpropagation.sampleNum = sampleNum;
	}

	/**
	 * Method for stohastic bacpropagation training
	 * @param network network to be trained
	 */
	public static void train(Network network) {
		Layer ol = network.getOutputLayer();
		Layer hl = network.getHiddenLayer();
		Layer il = network.getInputLayer();
		double[] deltaO = new double[ol.getSize()];
		double[] deltaH = new double[hl.getSize()];

		for (int it = 0; it < sampleNum; it++) {
			RandomData rd = new RandomData(network.getInNum(), network.getOutNum());
			network.getOutput(rd.getIn());

			// output layer error
			for (int i = 0; i < ol.getSize(); i++) {
				double o = ol.getNeuron(i).getOutput();
				deltaO[i] = o * (1 - o) * (rd.getOut(i) - o);
			}
			// hidden layer error
			for (int i = 0; i < hl.getSize(); i++) {
				double out = hl.getNeuron(i).getOutput();
				double summ = 0;
				for (int d = 0; d < ol.getSize(); d++) {
					summ += ol.getNeuron(d).getWeight(i + 1) * deltaO[d];
				}
				deltaH[i] = out * (1 - out) * summ;
			}

			// weight updates
			layerUpdate(hl, il, deltaH);
			layerUpdate(ol, hl, deltaO);
		}
	}

	private static void layerUpdate(Layer secondLayer, Layer firstLayer, double[] delta) {
		double val;
		for (int j = 0; j < secondLayer.getSize(); j++) {
			for (int i = 0; i < firstLayer.getSize(); i++) {
				val = secondLayer.getNeuron(j).getWeight(i + 1) + eta * firstLayer.getNeuron(i).getOutput() * delta[j];
				secondLayer.getNeuron(j).setWeight(i + 1, val);
			}
			//bias
			val = secondLayer.getNeuron(j).getWeight(0) + eta * delta[j];
			secondLayer.getNeuron(j).setWeight(0, val);
		}
	}

}
