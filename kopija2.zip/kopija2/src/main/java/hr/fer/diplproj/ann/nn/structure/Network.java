package hr.fer.diplproj.ann.nn.structure;

/**
 * CLass representing a three-layered artificial neural network
 * @author Andrea Zlati�
 */

public class Network {

	private Layer inputLayer;
	private Layer outputLayer;
	private Layer hiddenLayer;
	private int inNum;
	private int hidNum;
	private int outNum;

	/**
	 * Constructor for the neural network
	 * @param inNum number of neurons in the input layer
	 * @param hidNum number of neurons in the hidden layer
	 * @param outNum number of neurons in the output layer
	 */
	public Network(int inNum, int hidNum, int outNum) {
		this.inNum = inNum;
		this.hidNum = hidNum;
		this.outNum = outNum;
		inputLayer = new Layer(inNum, 1, NeuronFunctions.linearFunction());
		hiddenLayer = new Layer(hidNum, inNum, NeuronFunctions.sigmoidFunction());
		outputLayer = new Layer(outNum, hidNum, NeuronFunctions.sigmoidFunction());
	}

	/**
	 * Method which calculates the output of the network
	 * @param data which is run through the network
	 * @return the output result
	 */
	public double[] getOutput(double[] data) {

		inputLayer.calculateOutputs(data);
		hiddenLayer.setPrevs(inputLayer.getOutputs());

		hiddenLayer.calculateOutputs();
		outputLayer.setPrevs(hiddenLayer.getOutputs());

		outputLayer.calculateOutputs();

		return outputLayer.getOutputs();
	}

	public Layer getOutputLayer() {
		return outputLayer;
	}

	public Layer getHiddenLayer() {
		return hiddenLayer;
	}

	public Layer getInputLayer() {
		return inputLayer;
	}
	
	public int getInNum() {
		return inNum;
	}

	public int getHidNum() {
		return hidNum;
	}

	public int getOutNum() {
		return outNum;
	}

}
