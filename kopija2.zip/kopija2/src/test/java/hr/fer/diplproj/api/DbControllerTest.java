package hr.fer.diplproj.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import hr.fer.diplproj.models.PersonalUserData;
import hr.fer.diplproj.models.User;
import hr.fer.diplproj.repository.PersonalUserDataRepository;
import hr.fer.diplproj.repository.UserRepository;
import org.assertj.core.util.Lists;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.web.context.WebApplicationContext;
import hr.fer.diplproj.RestApplication;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = RestApplication.class)
@WebAppConfiguration
public class DbControllerTest {

    private static final String AUTH = "Authorization";
    private static final String ACCESS_TOKEN = "Basic YWRtaW46YWRtaW4=";
    @Autowired
    PersonalUserDataRepository personalUserDataRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    private WebApplicationContext webApplicationContext;
    private MockMvc mockMvc;
    private ObjectMapper mapper;

    @Before
    public void setup() throws Exception {
        this.mockMvc = webAppContextSetup(webApplicationContext).build();
        this.mapper = new ObjectMapper();
    }

    @Test
    public void getAllPersonalUserData() throws Exception {
        this.mockMvc
                .perform(get("/api/PersonalUserData")
                        .header(AUTH, ACCESS_TOKEN))
                .andExpect(status().isOk());
    }

    @Test
    public void getPersonalUserData() throws Exception {
        PersonalUserData expected = this.personalUserDataRepository.findOne(1);
        MvcResult mvcResult = this.mockMvc
                .perform(get("/api/PersonalUserData/1")
                        .header(AUTH, ACCESS_TOKEN))
                .andExpect(status().isOk()).andReturn();

        PersonalUserData resultData = this.mapper.readValue(mvcResult.getResponse().getContentAsString(), PersonalUserData.class);
        Assert.assertTrue(expected.equals(resultData));
    }

    @Test
    public void createPersonalUserDataTest() throws Exception {
        int sizeBefore = Lists.newArrayList(this.personalUserDataRepository.findAll()).size();

        PersonalUserData personalUserData = new PersonalUserData(1, "Ivan","Ivić");

        MvcResult mvcResult = this.mockMvc.perform(post("/api/PersonalUserData")
                .header(AUTH, ACCESS_TOKEN)
                .contentType(MediaType.APPLICATION_JSON)
                .content(this.mapper.writeValueAsString(personalUserData)))
                .andExpect(status().isOk()).andReturn();

        PersonalUserData resultData = this.mapper.readValue(mvcResult.getResponse().getContentAsString(), PersonalUserData.class);

        int sizeAfter = Lists.newArrayList(this.personalUserDataRepository.findAll()).size();

        Assert.assertEquals(sizeBefore, sizeAfter - 1);

        // clear data
        this.personalUserDataRepository.delete(resultData.getID());
    }

    @Test
    public void deletePersonalUserDataTest() throws Exception {
        PersonalUserData createdData = this.personalUserDataRepository.save(new PersonalUserData(1, "Ivan","Ivić"));

        Assert.assertNotNull(this.personalUserDataRepository.findOne(createdData.getID()));

        this.mockMvc.perform(delete("/api/PersonalUserData/" + createdData.getID())
                .header(AUTH, ACCESS_TOKEN))
                .andExpect(status().isOk());

        Assert.assertNull(this.personalUserDataRepository.findOne(createdData.getID()));
    }

    @Test
    public void updatePersonalUserDataTest() throws Exception {
        PersonalUserData createdData = this.personalUserDataRepository.save(new PersonalUserData(1, "Ivan","Ivić"));

        createdData.setFirstName("Ante");

        this.mockMvc.perform(put("/api/PersonalUserData/" + createdData.getID())
                .header(AUTH, ACCESS_TOKEN)
                .contentType(MediaType.APPLICATION_JSON)
                .content(this.mapper.writeValueAsString(createdData)))
                .andExpect(status().isOk()).andReturn();

        PersonalUserData personalUserData = this.personalUserDataRepository.findOne(createdData.getID());
        Assert.assertNotEquals("Ivan", personalUserData.getFirstName());
        Assert.assertEquals("Ante", personalUserData.getFirstName());

        // clear data
        this.personalUserDataRepository.delete(createdData.getID());
    }

    @Test
    public void getAllUsersTest() throws Exception {
        this.mockMvc
                .perform(get("/api/User")
                        .header(AUTH, ACCESS_TOKEN))
                .andExpect(status().isOk());
    }

    @Test
    public void getUserTest() throws Exception {
        User expected = this.userRepository.findOne(1);
        MvcResult mvcResult = this.mockMvc
                .perform(get("/api/User/1")
                        .header(AUTH, ACCESS_TOKEN))
                .andExpect(status().isOk()).andReturn();

        User resultUser = this.mapper.readValue(mvcResult.getResponse().getContentAsString(), User.class);
        Assert.assertTrue(expected.equals(resultUser));
    }

    @Test
    public void createUserTest() throws Exception {
        int sizeBefore = Lists.newArrayList(this.userRepository.findAll()).size();

        PersonalUserData personalUserData = personalUserDataRepository.save(new PersonalUserData(1, "Ivan","Ivić"));
        double[] test1 = {1.2d};
        double[] test3 = {3.4d};
        double[][] test2 = {test1, test3};

        User user = new User(1, test1,test2, test3);

        MvcResult mvcResult = this.mockMvc.perform(post("/api/User")
                .header(AUTH, ACCESS_TOKEN)
                .contentType(MediaType.APPLICATION_JSON)
                .content(this.mapper.writeValueAsString(user)))
                .andExpect(status().isOk()).andReturn();

        User resultUser = this.mapper.readValue(mvcResult.getResponse().getContentAsString(), User.class);
        int sizeAfter = Lists.newArrayList(this.userRepository.findAll()).size();

        Assert.assertEquals(sizeBefore, sizeAfter - 1);

        // clear data
        this.userRepository.delete(resultUser.getID());
        this.personalUserDataRepository.delete(personalUserData.getID());
    }

    @Test
    public void deleteUserTest() throws Exception {
        PersonalUserData personalUserData = new PersonalUserData(1, "Ivan","Ivić");
        double[] test1 = {1.2d};
        double[] test3 = {3.4d};
        double[][] test2 = {test1, test3};
        User user = this.userRepository.save(
                new User(1, test1,test2, test3));

        Assert.assertNotNull(this.userRepository.findOne(user.getID()));

        this.mockMvc.perform(delete("/api/User/" + user.getID())
                .header(AUTH, ACCESS_TOKEN))
                .andExpect(status().isOk());

        Assert.assertNull(this.personalUserDataRepository.findOne(user.getID()));

        // clear data
        this.personalUserDataRepository.delete(personalUserData.getID());
    }

    @Test
    public void updateUserTest() throws Exception {
        PersonalUserData personalUserData = personalUserDataRepository.save(new PersonalUserData(1, "Ivan","Ivić"));
        double[] test1 = {1.2d};
        double[] test3 = {3.4d};
        double[][] test2 = {test1, test3};
        User createdUser = this.userRepository.save(
                new User(1, test1,test2, test3));

        createdUser.setOut(test1);

        this.mockMvc.perform(put("/api/User/" + createdUser.getID())
                .header(AUTH, ACCESS_TOKEN)
                .contentType(MediaType.APPLICATION_JSON)
                .content(this.mapper.writeValueAsString(createdUser)))
                .andExpect(status().isOk()).andReturn();

        User user = this.userRepository.findOne(createdUser.getID());
        Assert.assertNotEquals("Tomislav", user.getOut());
        Assert.assertEquals("Tomo", user.getOut());

        // clear data
        this.userRepository.delete(user.getID());
        this.personalUserDataRepository.delete(personalUserData.getID());
    }


}
