package hr.fer.diplproj.rfid;

import hr.fer.diplproj.ann.nn.structure.Network;
import hr.fer.diplproj.ann.nn.train.StohasticBackpropagation;
import hr.fer.diplproj.models.Card;
import hr.fer.diplproj.models.User;
import hr.fer.diplproj.rfid.db.Database;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Random;
import java.util.stream.Stream;

public class RFIDANN {

	Network ann;
	ArrayList<Card> userCards;
	Database db;
	HashMap<Integer, Integer> availableUsers = new HashMap<>();


	public RFIDANN(int inputLayerNeurons,
					int hiddenLayerNeurons,
					int outputLayerNeurons) {

		userCards = new ArrayList<>();
		loadUsers();
		db = new Database();
		db.initFromFile(Constants.pathToDB);
	}

	private void loadUsers() {
		try (Stream<String> stream = Files.lines(Paths.get(Constants.pathToCards))) {
			stream.map(line -> new Card(line))
				.forEach(element -> {
					userCards.add(element);
					availableUsers.put(element.getID(), 0);
				});
		} catch (IOException e) {
			System.out.println(e);
		}
	}

	public void start() {
		Card inputCard;
		User u;

		//input
		double[][] inputWh, savedWo;
		double[] userR, output, expectedOutput;

		//output
		double[][] calculatedWh, calculatedWo;
		double[] calculatedOut;
		while(availableUsers.size() > 0) {
			ann = new Network(6, 6, 6);
			// wait for input
			inputCard = getInputCard();
			inputWh = inputCard.getData();

			u = db.getUser(inputCard.getID());
			if(u == null) {
				System.out.println("Unauthorised acces! UserID: " + inputCard.getID());
				continue;
			}

			userR = u.getR();
			savedWo = u.getWo();
			expectedOutput = u.getOut();

			// run through ANN
			// set ann hidden layer
			ann.getHiddenLayer().setWeightMatrixForPreviousLayer(inputWh);
			ann.getOutputLayer().setWeightMatrixForPreviousLayer(savedWo);

			boolean whCorrect = Constants.matrixToString(inputWh).equals(Constants.matrixToString(ann.getHiddenLayer().getWeightMatrixForPreviousLayer()));
			boolean woCorrect = Constants.matrixToString(savedWo).equals(Constants.matrixToString(ann.getOutputLayer().getWeightMatrixForPreviousLayer()));

			output = ann.getOutput(userR);

			if(Arrays.equals(output, expectedOutput)) {
				StohasticBackpropagation.train(ann);
				calculatedWh = ann.getHiddenLayer().getWeightMatrixForPreviousLayer();
				calculatedWo = ann.getOutputLayer().getWeightMatrixForPreviousLayer();
				calculatedOut = ann.getOutput(userR);

				saveToDB(inputCard.getID(), calculatedWo, calculatedOut);
				writeToOut(inputCard.getID(), calculatedWh);

				System.out.println("User " + inputCard.getID() + " passed!");
				boolean cardCopyOccured = new Random().nextInt(2)==0;
				if(cardCopyOccured) {
					writeToOut(inputCard.getID(), inputWh);
				}


			} else {
				System.out.println("User " + inputCard.getID() + " tried to pass with compromised card!");
				availableUsers.remove(inputCard.getID());
				continue;
			}
		}
		System.out.println("All users are compromised.");
	}

	private Card getInputCard() {
		Random r = new Random();
		Card c;
		do {
			int index = r.nextInt(userCards.size());
			c = userCards.get(index);
		} while (!availableUsers.containsKey(c.getID()));
		return c;
	}

	private Boolean saveToDB(int id, double[][] wo, double[] output) {
		return db.changeUserData(id, wo, output);
	}

	private void writeToOut(int id, double[][] wh) {
		for(int i = 0; i < userCards.size(); i++) {
			Card c = userCards.get(i);
			if(c.getID() == id) {
				c.setData(wh);
				userCards.set(i, c);
				break;
			}
		}
	}
}
