package hr.fer.diplproj.repository;

import org.springframework.data.repository.CrudRepository;

import hr.fer.diplproj.models.PersonalUserData;

public interface PersonalUserDataRepository extends CrudRepository<PersonalUserData, Integer> {
}
