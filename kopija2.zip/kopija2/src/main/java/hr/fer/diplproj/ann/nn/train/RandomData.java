package hr.fer.diplproj.ann.nn.train;

import java.util.Random;

/**
 * Class representing a random data sample
 * @author Andrea Zlati�
 *
 */
public class RandomData {
	
	private double[] inputs;
	private double[] outputs;
	
	public RandomData(int inNum, int outNum) {
		Random r = new Random();
		inputs = new double[inNum];
		outputs = new double[outNum];
		for (int i = 0; i < inNum; i++) {
			inputs[i] = r.nextDouble() * 4;
		}	

		for (int i = 0; i < outNum; i++) {
			outputs[i] = r.nextDouble() * 4;
		}	
	}

	public double[] getIn() {
		return inputs;
	}

	public double getOut(int i) {
		return outputs[i];
	}
	
}
