package hr.fer.diplproj.rfid;

import hr.fer.diplproj.ann.nn.structure.Network;
import hr.fer.diplproj.ann.nn.train.StohasticBackpropagation;
import hr.fer.diplproj.models.Card;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Random;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Main {

	public static void main(String[] args) {
		System.out.println("Started user creation.");
		createUsers();
		System.out.println("Ended user creation.");
		RFIDANN system = new RFIDANN(Constants.N, Constants.H, Constants.N);
		system.start();


//		Network ann = new Network(6, 6, 6);
//		StohasticBackpropagation.train(ann);
//		double[] R = {1.0, 2.1, 3.2, 4.3, 5.4, 6.5};
//		double[][] wh = ann.getHiddenLayer().getWeightMatrixForPreviousLayer();
//		double[][] wo = ann.getOutputLayer().getWeightMatrixForPreviousLayer();
//		double[] out1 = ann.getOutput(R);
//
//
//		Network nn = new Network(6, 6, 6);
//		nn.getHiddenLayer().setWeightMatrixForPreviousLayer(wh);
//		nn.getOutputLayer().setWeightMatrixForPreviousLayer(wo);
//		double[] out2 = nn.getOutput(R);
//
//		System.out.println(Arrays.equals(out1, out2));


	}

	private static void createUsers() {
		writeFirstLine();

		ArrayList<String> cards = new ArrayList<>();

		Stream<String> userData = IntStream.range(0, Constants.numbeOfUsers)
				.mapToObj(id -> {
					Network ann = new Network(Constants.N, Constants.H, Constants.N);
					StohasticBackpropagation.train(ann);

					double[] R = new Random().doubles(Constants.N, -100.0, 100.0).toArray();
					double[][] Wh = ann.getHiddenLayer().getWeightMatrixForPreviousLayer();
					double[][] Wo = ann.getOutputLayer().getWeightMatrixForPreviousLayer();
					double[] out = ann.getOutput(R);

					Card card = new Card(id, Wh);
					cards.add(card.toString());

					return id + ";" +
							Constants.arrayToString(R) + ";" +
							Constants.matrixToString(Wo) + ";" +
							Constants.arrayToString(out);

				});

		try {
			Files.write(Paths.get(Constants.pathToDB), (Iterable<String>)userData::iterator, StandardOpenOption.APPEND);
			Files.write(Paths.get(Constants.pathToCards), (Iterable<String>)cards::iterator);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void writeFirstLine() {
		try {
			String setup = Constants.N + ";" + Constants.H;
			BufferedWriter writer = new BufferedWriter(new FileWriter(Constants.pathToDB));
			writer.write(setup);
			writer.newLine();
			writer.close();
		} catch (IOException e) {
			System.out.println(e);
		}

	}
}
