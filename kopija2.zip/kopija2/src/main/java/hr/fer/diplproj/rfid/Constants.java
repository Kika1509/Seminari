package hr.fer.diplproj.rfid;

import java.util.Arrays;
import java.util.stream.Stream;

public class Constants {

	public static final int N = 6;
	public static final int H = 6;
	
	public static final String inputInvalidSize = "Input shoudl be the size of " + N;
	public static final String whInvalidSize = "Wh should be of size " + N + "x" + H;
	public static final String woInvalidSize = "Wo should be of size " + H + "x" + N;	
	
	public static final int numbeOfUsers = 10;
	public static final String pathToDB = "./resources/db.txt";
	public static final String pathToCards = "./resources/cards.txt";
	
	public static String matrixToString(double[][] matrix) {
		StringBuilder sb = new StringBuilder();
		for(int i = 0; i < matrix.length; i++) {
			for(int j = 0; j < matrix[i].length; j++) {
				sb.append(matrix[i][j] + ",");
			}
		}
		int endIndex = sb.length() - 1;
		return sb.substring(0, endIndex);
	}
	
	public static String arrayToString(double[] array) {
		return Arrays.stream(array)
				.boxed()
				.map(Object::toString)
				.reduce((a, b) -> a + "," + b)
				.get();
	}
	
	public static double[][] matrixFromString(String data, int rows) {
		String[] elements = data.split(",");
		int columns = elements.length / rows;
		double[][] matrix = new double[rows][columns];
		
		for(int i = 0; i < rows; i++) {
			for(int j = 0; j < columns; j++) {
				matrix[i][j] = Double.parseDouble(elements[i * columns + j]);
			}
		}
		return matrix;
	}
	
	public static double[] arrayFromString(String data) {
		return Stream.of(data.split(","))
				.mapToDouble(x -> Double.parseDouble(x))
				.toArray();
	}
}
