package hr.fer.diplproj.ann.nn.structure;

import java.util.Random;

/**
 * Class representing one neuron in a layer
 * @author Andrea Zlati�
 */
public class Neuron {

	private double[] w;
	private double out;
	private NeuronFunction fun;

	/**
	 * Constructor for a neuron
	 * @param n number of incoming outputs from a previous layer
	 * @param fun activating funcion of the neuron
	 */
	
	public Neuron(int n, NeuronFunction fun) {		
		//initialising weights
		w = new double[n+1];
		Random r = new Random();
		for (int i = 0; i < n+1; i++) {
			w[i] = r.nextGaussian();
		}
		this.fun = fun;
	}

	/**
	 * Getter for the neuron output
	 * @return output of the neuron
	 */
	public double getOutput() {
		return out;
	}
	
	/**
	 * Calculates the output of a neuron
	 * @param x input to the neuron
	 */
	public void calculateOutput(double x[]) {
		//setting a dummy value 1 to group the bias with regular weights
		double[] x2 = new double[x.length+1];
		x2[0] = 1;
		System.arraycopy(x, 0, x2, 1, x.length);
		
		out = fun.calculateValue(x2, w);
	}

	/**
	 * Getter for the weights of the neuron
	 * @return weights of the neuron
	 */
	public double[] getWeights() {
		return w;
	}

	/**
	 * Getter for a specified weight of the neuron
	 * @param index of the weight to be fetched
	 * @return weight of the neuron
	 */
	public double getWeight(int i) {
		return w[i];
	}

	/**
	 * Setter for a specified weight of the neuron
	 * @param i index of the weight to be set
	 * @param val value of the weight to be set
	 */
	public void setWeight(int i, double val) {
		w[i] = val;
	}

}
