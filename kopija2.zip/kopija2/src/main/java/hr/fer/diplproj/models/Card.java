package hr.fer.diplproj.models;

import hr.fer.diplproj.rfid.Constants;

public class Card {
	private int ID;
	private double[][] data;

	public Card(int argId, double[][] argData) {
		this.ID = argId;
		this.data = argData;
	}

	public Card(String data) {
		String[] elements = data.split(";");
		this.ID = Integer.parseInt(elements[0]);
		this.data = Constants.matrixFromString(elements[1], Constants.N);
	}

	public int getID() {
		return this.ID;
	}

	public double[][] getData() {
		return this.data;
	}

	public void setData(double[][] data) {
		this.data = data;
	}

	public String toString() {
		return this.ID + ";" + Constants.matrixToString(data);
	}
}
