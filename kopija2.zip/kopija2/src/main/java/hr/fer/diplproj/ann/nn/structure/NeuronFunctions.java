package hr.fer.diplproj.ann.nn.structure;

/**
 * Class containing the activationg functions of neurons
 * @author Andrea Zlati�
 */
public class NeuronFunctions {

	/**
	 * Linear function of the neurons in the first layer
	 * @return a linear function
	 */
	public static NeuronFunction linearFunction() {
		return new NeuronFunction() {
			@Override
			public double calculateValue(double[] x, double[] w) {
				return x[0];
			}
		};
	}
	
	/**
	 * Sigmoid function of the neurons in the hidden and output layers
	 * @return a sigmoid function
	 */
	public static NeuronFunction sigmoidFunction() {
		return new NeuronFunction() {
			@Override
			public double calculateValue(double[] x, double[] w) {
				double sum = 0;
				for (int i = 0; i < w.length; i++) {
					sum += w[i] * x[i];
				}
				return 1.0 / (1 + Math.exp(-sum));
			}
		};
	}
}
