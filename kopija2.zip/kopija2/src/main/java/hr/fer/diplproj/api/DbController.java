package hr.fer.diplproj.api;

import hr.fer.diplproj.models.PersonalUserData;
import hr.fer.diplproj.models.User;
import hr.fer.diplproj.repository.PersonalUserDataRepository;
import hr.fer.diplproj.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.persistence.criteria.CriteriaBuilder;


@RestController
@RequestMapping(path = "/api")
public class DbController {
    @Autowired
    PersonalUserDataRepository personalUserDataRepository;

    @Autowired
    UserRepository userRepository;


        @GetMapping(path = "")
        public String getDocs() {
            StringBuilder builder = new StringBuilder();
            builder.append("\n---------------- PersonalUserData ----------------");
            builder.append("\nGET /PersonalUserData - get all personal user data");
            builder.append("\nGET /PersonalUserData/{ID} - get user with {id}");
            builder.append("\nPOST /PersonalUserData - create new personal user data");
            builder.append("\nDELETE /PersonalUserData/{id} - delete user with {id}");
            builder.append("\nPUT /PersonalUserData/{id} - update user with {id}");
            builder.append("\n\n---------------- User ----------------");
            builder.append("\nGET /User - get all users");
            builder.append("\nGET /User/{id} - get user with {id}");
            builder.append("\nPOST /User - create new user");
            builder.append("\nDELETE /User/{id} - delete user with {id}");
            builder.append("\nPUT /User/{id} - update user with {id}");
            builder.append("\n\nGET /PersonalUserData/{id}/User - get user entries of user with {id}");

            return builder.toString();
        }

        @GetMapping(path = "/PersonalUserData")
        public @ResponseBody
        Iterable<PersonalUserData> getAllPersonalUserData(@RequestHeader("Authorization") String auth) {
            return this.personalUserDataRepository.findAll();
        }

        @GetMapping(path = "/PersonalUserData/{id}")
        public @ResponseBody
        PersonalUserData getPersonalUserData(@PathVariable Integer id) {
            return this.personalUserDataRepository.findOne(id);
        }

        @PostMapping(value = "/PersonalUserData")
        public ResponseEntity addPersonalUserData(@RequestBody PersonalUserData personalUserData) {
            try {
                PersonalUserData result = this.personalUserDataRepository.save(personalUserData);
                return ResponseEntity.ok().body(result);
            } catch (Exception e) {
                return ResponseEntity.badRequest().body(null);
            }
        }

        @DeleteMapping(path = "/PersonalUserData/{id}")
        public ResponseEntity deletePersonalUserData(@PathVariable Integer id) {
            try {
                this.personalUserDataRepository.delete(id);
                return ResponseEntity.ok().body("User deleted.");
            } catch (Exception e) {
                return ResponseEntity.badRequest().body(null);
            }
        }

        @PutMapping(path = "/PersonalUserData/{id}")
        public ResponseEntity updatePersonalUserData(@PathVariable Integer id, @RequestBody PersonalUserData personalUserData) {
            try {
                personalUserData.setID(id);
                PersonalUserData result = this.personalUserDataRepository.save(personalUserData);
                return ResponseEntity.ok().body(result);
            } catch (Exception e) {
                return ResponseEntity.badRequest().body(null);
            }
        }

        @GetMapping(path = "/User")
        public @ResponseBody
        Iterable<User> getAllUsers() {
            return this.userRepository.findAll();
        }

        @GetMapping(path = "/User/{id}")
        public @ResponseBody
        User getUser(@PathVariable Integer id) {
            return this.userRepository.findOne(id);
        }

        @PostMapping(value = "/User")
        public ResponseEntity addUser(@RequestBody User user) {
            try {
                this.userRepository.save(user);
                return ResponseEntity.ok().body(user);
            } catch (Exception e) {
                return ResponseEntity.badRequest().body(null);
            }
        }

        @DeleteMapping(path = "/User/{id}")
        public ResponseEntity deleteUser(@PathVariable Integer id) {
            try {
                this.userRepository.delete(id);
                return ResponseEntity.ok().body("User deleted");
            } catch (Exception e) {
                return ResponseEntity.badRequest().body(null);
            }
        }

        @PutMapping(path = "/User/{id}")
        public ResponseEntity updateUser(@PathVariable Integer id, @RequestBody User user) {
            try {
                user.setID(id);
                User result = this.userRepository.save(user);
                return ResponseEntity.ok().body(result);
            } catch (Exception e) {
                return ResponseEntity.badRequest().body(null);
            }
        }

        @GetMapping(path = "/PersonalUserData/{id}/User")
        public @ResponseBody
        Iterable<User> getAllPersonalUserDataUsers(@PathVariable Integer id) {
            return this.userRepository.findByID(id);
        }

    }

