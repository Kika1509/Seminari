package hr.fer.diplproj.models;

import hr.fer.diplproj.rfid.Constants;

public class User {

	private int ID;
	private double[] R;
	private double[][] Wo;
	private double[] out;

	public User(int argID, double[] argR, double[][] argWo, double[] argOut) {
		if(isIORightSize(argR) && isWoRightSize(argWo)) {
			this.ID = argID;
			this.R = argR;
			this.Wo = argWo;
			this.out = argOut;
		} else {
			String message = Constants.inputInvalidSize + " " + Constants.woInvalidSize;
			throw new IllegalArgumentException(message);
		}
	}

	public void setID(int ID) {
		this.ID = ID;
	}

	public int getID() {
		return this.ID;
	}

	public double[] getR() {
		return R;
	}

	public double[][] getWo() {
		return Wo;
	}

	public void setWo(double[][] wo) {
		if(isWoRightSize(wo)) {
			this.Wo = wo;
		} else {
			throw new IllegalArgumentException(Constants.woInvalidSize);
		}
	}

	public double[] getOut() {
		return out;
	}

	public void setOut(double[] out) {
		this.out = out;
	}

	private boolean isIORightSize(double[] input) {
		return input.length == Constants.N;
	}

	private boolean isWoRightSize(double[][] Wo) {
		return Wo.length == Constants.H && Wo[0].length == Constants.N + 1;
	}


	public String toString() {
		return "";
	}

}
