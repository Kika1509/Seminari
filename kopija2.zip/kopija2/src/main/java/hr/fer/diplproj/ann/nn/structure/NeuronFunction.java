package hr.fer.diplproj.ann.nn.structure;

/**
 * Abstract class representing an activation function of a neuron
 * @author Andrea Zlati�
 */
public abstract class NeuronFunction {
	
	abstract public double calculateValue(double[] x, double[] w);

}
