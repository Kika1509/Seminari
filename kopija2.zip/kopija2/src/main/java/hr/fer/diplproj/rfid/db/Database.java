package hr.fer.diplproj.rfid.db;

import hr.fer.diplproj.models.User;
import hr.fer.diplproj.rfid.Constants;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.stream.Stream;

public class Database {

	HashMap<Integer, User> db;

	public Database() {
		this.db = new HashMap<>();
	}

	public void initFromFile(String pathToFile) {
		// first row: N;H
		// other rows should look like: id;R1,R2,...,RN;Wo11,Wo12,...,WoIJ,..,WoHN;out1,out2,...outN\n
		try (Stream<String> stream = Files.lines(Paths.get(pathToFile))) {

			stream.forEach(line -> {
				String[] elements = line.split(";");

				if(elements.length == 2) {
					int n = Integer.parseInt(elements[0]);
					int h = Integer.parseInt(elements[1]);
					if(n != Constants.N || h != Constants.H) {
						System.out.println("Invalid file");
						System.exit(-1);
					}
				} else if(elements.length == 4){
					int id = Integer.parseInt(elements[0]);

					double[] R = Stream.of(elements[1].split(","))
							.mapToDouble(x -> Double.parseDouble(x))
							.toArray();

					double[][] Wo = new double[Constants.H][Constants.N + 1];
					String[] wo = elements[2].split(",");
					for(int i = 0; i < Constants.H; i++) {
						for(int j = 0; j < Constants.N + 1; j++) {
							Wo[i][j] = Double.parseDouble(wo[i * (Constants.N + 1) + j]);
						}
					}

					double[] out = Stream.of(elements[3].split(","))
							.mapToDouble(x -> Double.parseDouble(x))
							.toArray();

					db.put(id, new User(id, R, Wo, out));
				}
			});


		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	public User getUser(int userID) {
		return db.getOrDefault(userID, null);
	}

	public boolean addUser(User user) {
		if(db.containsKey(user.getID())) return false;
		db.put(user.getID(), user);
		return true;
	}

	public boolean changeUserData(int id, double[][] wo, double[] out) {
		if(!db.containsKey(id)) return false;
		User u = db.get(id);
		u.setWo(wo);
		u.setOut(out);
		db.replace(id, u);
		return true;
	}

	public void printUsers() {
		System.out.println(db.keySet());
	}
}
