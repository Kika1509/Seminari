package hr.fer.diplproj.repository;

import org.springframework.data.repository.CrudRepository;
import hr.fer.diplproj.models.User;

public interface UserRepository extends CrudRepository<User, Integer> {

    Iterable<User> findByID(Integer id);
}
