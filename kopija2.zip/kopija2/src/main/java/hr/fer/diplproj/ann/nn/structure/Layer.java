package hr.fer.diplproj.ann.nn.structure;

/**
 * Class representing a layer in a neural network
 * @author Andrea Zlati�
 */
public class Layer {

	private Neuron[] neurons;
	private double[] prev;
	private double[] outputs;
	
	/**
	 * Constructor for a layer in a neural network
	 * @param n number of neurons in the layer
	 * @param prevNum number of neurons in the previous layer
	 * @param fun activating function of the neurons in the layer
	 */
	public Layer(int n, int prevNum, NeuronFunction fun) {
		neurons = new Neuron[n];
		for (int i = 0; i < n; i++) {
			neurons[i] = new Neuron(prevNum, fun);
		}
		outputs = new double[n];
	}

	/**
	 * Getter for the number of neurons in the layer
	 * @return number of neurons in the layer
	 */
	public int getSize() {
		return neurons.length;
	}

	/**
	 * Setter for an output value of the previous layer
	 * @param i index of the neuron of the previous layer
	 * @param output of the neuron of the previous layer
	 */
	public void setPrev(int i, double output) {
		prev[i] = output;
	}
	
	/**
	 * Setter for the whole previous layer
	 * @param prev the previous layer
	 */
	public void setPrevs(double[] prev) {
		this.prev = prev;
	}
	
	/**
	 * Getter for a neuron in the layer
	 * @param i index of the neuron to be fetched
	 * @return the neuron to be fetched
	 */
	public Neuron getNeuron(int i) {
		return neurons[i];
	}
	
	/**
	 * Calculates the ouputs of all the neurons in the layer
	 */
	public void calculateOutputs() {
		for (int i = 0; i < neurons.length; i++) {
			neurons[i].calculateOutput(prev);
			outputs[i] = neurons[i].getOutput();
		}
	}
	
	/**
	 * Getter for the outputs of neurons in the layer
	 * @return outputs of the neurons in the layer
	 */
	public double[] getOutputs() {
		return outputs;
	}

	/**
	 * Calculates the outputs of the neurons in the layer given the input data
	 * @param data the given data
	 */
	public void calculateOutputs(double[] data) {
		for (int i = 0; i < neurons.length; i++) {
			neurons[i].calculateOutput(new double[] {data[i]} );
		}	
	}
	
	public double[][] getWeightMatrixForPreviousLayer() {
		double[][] weights = new double[neurons.length][];
		for(int i = 0; i < neurons.length; i++) {
			weights[i] = neurons[i].getWeights();
		}
		return weights;
	}
	
	public void setWeightMatrixForPreviousLayer(double[][] weights) {
		for(int i = 0; i < weights.length; i++) {
			for(int j = 0; j < weights[i].length; j++) {
				neurons[i].setWeight(j, weights[i][j]);
			}
		}
	}

}
